var requirejsConfig = {
    // By default load any module IDs from js/modules
    baseUrl: '/js/modules',
    // Optionally specify different paths for specific modules
    paths: {
        lib: '/js/libs'
    }
};
requirejs.config(requirejsConfig);