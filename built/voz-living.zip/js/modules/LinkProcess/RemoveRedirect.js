define(function() {
    return {
        run:function($context){
            $context.find("a[href*='redirect/index.php']").each(function(){
                var $this = $(this);
                var url = $this.attr("href").match(/\?link=(.*)/)[1];
                var decoded = decodeURIComponent(url);
                $this.attr("href",decoded);
            })
        }
    }
});
